class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class SortedCircularLinkedList {
    Node head;

    
    void insert(int newData) {
        Node newNode = new Node(newData);

   
        if (head == null) {
            head = newNode;
            newNode.next = head;
        } else if (newData <= head.data) {
           
            newNode.next = head;
            Node temp = head;
            while (temp.next != head) {
                temp = temp.next;
            }
            temp.next = newNode;
            head = newNode;
        } else {
          
            Node temp = head;
            while (temp.next != head && temp.next.data < newData) {
                temp = temp.next;
            }

            newNode.next = temp.next;
            temp.next = newNode;
        }
    }

    void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node temp = head;
        do {
            System.out.print(temp.data + " ");
            temp = temp.next;
        } while (temp != head);
        System.out.println();
    }

    public static void main(String[] args) {
        SortedCircularLinkedList circularList = new SortedCircularLinkedList();

    
        circularList.insert(2);
        circularList.insert(4);
        circularList.insert(6);
        circularList.insert(8);

     
        System.out.println("Original Sorted Circular Linked List:");
        circularList.display();

     
        int newElement = 5;
        circularList.insert(newElement);

      
        System.out.println("Sorted Circular Linked List after inserting " + newElement + ":");
        circularList.display();
    }
}
